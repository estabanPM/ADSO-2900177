/**imprimir el porcentaje de un número.
 * Autor: Esteban Palomar Murcia
 * Fecha: Jueves 04 de abril del 2024
 */

//con parametro
function porNumero(pnumero){
    let numero = pnumero;
    let rnumero;

    rnumero= numero/100;
    return rnumero;
}

//con expresión
const porNumeroExp = function(pnumero){
    let numero = pnumero;
    let rnumero;

    rnumero= numero/100;
    return rnumero;
}