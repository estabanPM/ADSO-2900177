/**
 * imprimir el resultado de la suma de dos numeros
 * autor: Esteban Palomar Murcia
 * Fecha: lunes 01 de marzo del 2024
 */

let numeroUno;
let numeroDos;
//como parametro
function suma(pnumeroUno, pnumeroDos){
    numUno=pnumeroUno;
    numDos=pnumeroDos;
    let sumar;
    sumar= numUno+numDos;
    return sumar

}
//como expresión
const sumaExp = function(pnumeroUno, pnumeroDos){
    let sumar;
    numeroUno = pnumeroUno;
    numeroDos = pnumeroDos;
    sumar = numeroUno+numeroDos;
    return sumar;
}