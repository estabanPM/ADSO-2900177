/**
 * funcion saludo - hola mundo
 * autor: Esteban Palomar Murcia
 * Fecha: lunes 01 de marzo del 2024
 */

//como Parametros
function saludo(psaludo){
    let saludar = psaludo;
    return saludar;
}

//como expresión
const saludoExp = function(psaludo){
    let saludar = psaludo;
    return saludar;
} 